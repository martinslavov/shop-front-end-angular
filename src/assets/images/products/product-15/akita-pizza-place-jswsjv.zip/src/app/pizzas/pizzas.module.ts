import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PizzasComponent } from './pizzas.component';

@NgModule({
  imports: [CommonModule],
  declarations: [PizzasComponent],
  exports: [PizzasComponent]
})
export class PizzasModule {}
